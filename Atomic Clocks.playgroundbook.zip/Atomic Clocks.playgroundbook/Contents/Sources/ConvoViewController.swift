
import UIKit


public class ConvoController: UIViewController {
    
    // MARK: - Variables

    var iPhoneLabel = UILabel()

    var serverLabel = UILabel()
    
    var clockLabel = UILabel()
    
    
    var iPhoneSpeaking = UILabel()
    
    var serverSpeaking = UILabel()
    
    
    
    // MARK: - Typing Helpers
    
    
    var timer: Timer!

    var charIndex = Int()
    
    var currentLabel: UILabel!

    var currentString = Array("")
    
    
    var convIndex = Int()
    
    
    // MARK: - Conversation
    
    let conversation: [ConversationItem] = [
    
        ConversationItem(speaker: 0, text: "Hi, I'm Bram's iPhone X", delay: 1.5),
        ConversationItem(speaker: 1, text: "Oh hi there, I'm an NTP server", delay: 2.0),
        ConversationItem(speaker: 0, text: "So listen, this is kind of embarrassing...", delay: 3.0),
        ConversationItem(speaker: 0, text: "I completely lost track of time.. Can you help me out?", delay: 2.0),
        ConversationItem(speaker: 1, text: "My built-in atomic clock got your back, man", delay: 2.5),
        ConversationItem(speaker: 1, text: "It's currently ", delay: 0.7),
        ConversationItem(speaker: 0, text: "Thanks, man! Let me adjust that clock", delay: 4.0),
        ConversationItem(speaker: 0, text: "Hey, that's not Belgian time! That's SF time!", delay: 2.0),
        ConversationItem(speaker: 1, text: "I assumed you were going to WWDC because of how awesome this Playground is, so I already adjusted the time.", delay: 3.5),
        ConversationItem(speaker: 0, text: "Aww, how nice! Let's hope the judges think it's awesome, too 😝", delay: 0.0)

    ]
    
    
    // MARK: - ViewDiDLoad
    
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        
    
        
        // Create the iPhone X
        
        let iPhoneX = UIImageView(frame: CGRect(x: view.frame.minX + 50, y: view.frame.minY + 75, width: 225, height: 452))
        
        iPhoneX.image = UIImage(named: "iPhone X.png")
        iPhoneX.contentMode = .scaleAspectFit
        
        
        view.addSubview(iPhoneX)
        
        
        // Create the clock label
        
        
        clockLabel = UILabel(frame: CGRect(x: iPhoneX.frame.midX - 110, y: view.frame.minY + 143, width: 220, height: 50))
        
        clockLabel.text = "0:00"
        clockLabel.textColor = .white
        clockLabel.font = UIFont.systemFont(ofSize: 40)
        clockLabel.layer.zPosition = 10
        clockLabel.textAlignment = .center
        
        view.addSubview(clockLabel)
        
        
        // Create the iPhone label
        
        
        let leftWidth = view.frame.minX + 50 + iPhoneX.frame.width + 45
        
        iPhoneLabel = UILabel(frame: CGRect(x: leftWidth, y: view.frame.minY + 175, width: (view.frame.width / 2) - leftWidth - 45, height: 200))
        
        iPhoneLabel.text = ""
        iPhoneLabel.font = UIFont(name: "AvenirNext-Regular", size: 20)
        iPhoneLabel.numberOfLines = 0

        
        view.addSubview(iPhoneLabel)
        
        
        
        // Create the iPhoneSpeaking label
        
        
        iPhoneSpeaking = UILabel(frame: CGRect(x: leftWidth + 75, y: view.frame.minY + 30, width: (view.frame.width / 2) - leftWidth - 45, height: 200))
        
        iPhoneSpeaking.text = "💬"
        iPhoneSpeaking.alpha = 0
        iPhoneSpeaking.font = UIFont(name: "AvenirNext-Regular", size: 70)
        iPhoneSpeaking.numberOfLines = 0
        
        
        view.addSubview(iPhoneSpeaking)
        
        
        
        
        // Create the server
        
        let server = UIImageView(frame: CGRect(x: (view.frame.width / 2) - 235, y: view.frame.maxY - 255, width: 130, height: 130))
        
        server.image = UIImage(named: "Server.png")
        server.contentMode = .scaleAspectFit
        
        view.addSubview(server)
        

        
        
        // Create the server label
        
        
        let rightWidth: CGFloat = 235.0 + 45.0
        
        serverLabel = UILabel(frame: CGRect(x: view.frame.minX + 60, y: view.frame.maxY - 255, width: (view.frame.width / 2) - rightWidth - 60, height: 150))
        
        serverLabel.text = ""
        serverLabel.font = UIFont(name: "AmericanTypewriter", size: 19)
        serverLabel.numberOfLines = 0
        
        view.addSubview(serverLabel)
        
        
        // Create the serverSpeaking label
        
        
        serverSpeaking = UILabel(frame: CGRect(x: (view.frame.width / 2) - 200, y: server.frame.minY - 150, width: (view.frame.width / 2) - rightWidth - 60, height: 150))
        
        serverSpeaking.text = "💬"
        serverSpeaking.alpha = 0
        serverSpeaking.font = UIFont(name: "AvenirNext-Regular", size: 70)
        serverSpeaking.numberOfLines = 0
        
        view.addSubview(serverSpeaking)

        
        // Start the typing after an initial delay
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            
            self.displayNextItem()
            
        }
    }
    

    // MARK: - Typing helpers
    
    func displayNextItem() {
        
        if convIndex < conversation.count {
            
            
            // Determine current item
            
            let item = conversation[convIndex]
    
            let clearingDelay = 0.55
            
            
            // Determine the label
            
            
            switch item.speaker {
                
            case 0:

                currentLabel = iPhoneLabel
                
                clearUpcomingLabel()
                
                
                // Change text and animate alpha
                
                DispatchQueue.main.asyncAfter(deadline: .now() + clearingDelay) {
                    
                    self.currentLabel.alpha = 0
                    self.currentLabel.text = item.text
                    
                    UIView.animate(withDuration: 1.0, animations: {
                        
                        self.currentLabel.alpha = 1
                        
                    })
                    
                    // Modify the clock when the time's right (see what I did there?)
                    
                    if self.convIndex == 6 {
                        
                        self.modifyClock()
                        
                    }
                }
                
                
                // Respect delay
                
                DispatchQueue.main.asyncAfter(deadline: .now() + item.delay) {
                    
                    self.convIndex += 1

                    self.displayNextItem()

                }
                
                
            case 1:
                
                currentLabel = serverLabel
                
                clearUpcomingLabel()

                
                // Append time to item 5
                
                var text = item.text
                
                
                if convIndex == 5 {
                    
                    text = text + currentSFTime(includeAM: true)
                    
                }
                
                // Split the current string
                
                currentString = Array(text)
                
                // Initiate sequence by typing the first letter
                
                timer = Timer.scheduledTimer(timeInterval: 0.5 + clearingDelay, target: self, selector: #selector(self.type), userInfo: nil, repeats: true)
                
            default: break
                
            }
        }
    }
    
    func type() {
        
        
        if charIndex < currentString.count {
            
            // Set the text
            
            currentLabel.text = currentLabel.text! + String(currentString[charIndex])

            
            // Type the next letter after a random period of time
            
            let randomInterval = Double((arc4random_uniform(8) + 1)) / 75
            
            timer.invalidate()
            
            timer = Timer.scheduledTimer(timeInterval: randomInterval, target: self, selector: #selector(self.type), userInfo: nil, repeats: false)
            
            
            // Increment the index
            
            charIndex += 1

        } else {
            
            // Add a delay or start typing the next item
            
            timer.invalidate()
            
            charIndex = 0

            convIndex += 1
            
            
            // Start with next item after delay
            
            DispatchQueue.main.asyncAfter(deadline: .now() + conversation[convIndex].delay) {
                
                self.displayNextItem()
                
            }

        }
    }
    
    
    func clearUpcomingLabel() {
        
        // Animate the label out
        
        UIView.animate(withDuration: 0.5, animations: {
            
            self.currentLabel.alpha = 0

        }, completion: { (success) in
            
            self.currentLabel.text = ""

            self.currentLabel.alpha = 1.0
            
        })
        
        
        
        // Animate the right speaker in
        
        
        if self.currentLabel == self.iPhoneLabel {
            
            // Immediately animate out
            
            UIView.animate(withDuration: 0.5, animations: {
                
                self.serverSpeaking.alpha = 0.0
                
                if self.convIndex == 0 {
                    
                    //self.iPhoneSpeaking.alpha = 1.0
                    
                }
                
            })
            
            // Animate in after delay
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {

                UIView.animate(withDuration: 0.5, animations: {
                    
                    self.iPhoneSpeaking.alpha = 1.0
                    
                })
            }
            
        } else {
            
            UIView.animate(withDuration: 0.5, animations: {
                
                self.iPhoneSpeaking.alpha = 0.0
                self.serverSpeaking.alpha = 1.0
                
            })
        }
    
            
    }
    
    func modifyClock() {
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            
            UIView.animate(withDuration: 0.5, animations: {
                
                self.clockLabel.alpha = 0.0
                
            }, completion: { (success) in
                
                self.clockLabel.text = self.currentSFTime()
                
                UIView.animate(withDuration: 0.5, animations: {
                    
                    self.clockLabel.alpha = 1.0
                    
                })
            })
            
        }
        
    }
    
    func currentSFTime(includeAM: Bool = false) -> String {
        
        let now = Date()
        let formatter = DateFormatter()
        
        
        // Set locale (for 12-hr representation) and time zone Cali
        
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(abbreviation: "PDT")
        
        // Append AM and PM if requested
        
        if includeAM {
            
            formatter.dateFormat = "hh:mm a"
            formatter.amSymbol = "AM"
            formatter.pmSymbol = "PM"
            
        } else {
            
            formatter.dateFormat = "hh:mm"
            
        }
        
        
        return formatter.string(from: now) ?? "0:00"

    }
    
}




// MARK: - Supporting Struct

public struct ConversationItem {
    
    public var text: String
    public var speaker: Int
    public var delay: Double

    
    // MARK: - Initialization
    
    public init(speaker: Int, text: String, delay: Double) {
        
        self.text = text
        self.speaker = speaker
        self.delay = delay
        
    }
    
}
