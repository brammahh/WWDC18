import Foundation
import SpriteKit
import GameplayKit

public class Scene: SKScene {
    
    
    // MARK: - Reusability-related
    
    var atom: SKShapeNode!
    
    var atomAction: SKAction!
    
    var bendAction: SKAction!
    

    
    var wave: SKShapeNode!

    var waveAction: SKAction!
    
    
    
    // MARK: - Out of sync
    
    
    var frequencyLabel: SKLabelNode!
    
    

    // MARK: - Spawning
    
    
    var spawnedAtoms = 0

    var bendNextAtom = false

    public var bendingEnabled = false
    
    
    var spawnedWaves = 0
    
    
    var timer: Timer!
    


    
    // MARK: - ViewDidLoad

    
    override public func didMove(to view: SKView) {
        
        
        
        // MARK: - Style the view
        
        
        self.backgroundColor = .white
        
        
        
        
        
        
        
        // MARK: - Shooting Atoms
        
        
        
        
        // MARK: - Create the Cesium atom container
        
        let atomContainer = SKShapeNode(rect: CGRect(x: 0, y: 0, width: 100, height: 80), cornerRadius: 10)
        
        atomContainer.fillColor = UIColor(red:0.20, green:0.29, blue:0.37, alpha:1.0)
        atomContainer.position = CGPoint(x: (-self.frame.width / 4) + 25, y: self.frame.height / 2 - 250)
        self.addChild(atomContainer)
        
        
        // MARK: - Atom Label
        
        let atomLabel = SKLabelNode(text: "Cesium Atoms")
        
        atomLabel.fontColor = .black
        atomLabel.fontName = "AvenirNext-DemiBold"
        atomLabel.fontSize = 30
        atomLabel.position = CGPoint(x: atomContainer.frame.midX, y: atomContainer.position.y + 125)
        
        self.addChild(atomLabel)
        
        
        // MARK: - Create the Detector
        
        let detector = SKShapeNode(rect: CGRect(x: 0, y: 0, width: 100, height: 80), cornerRadius: 10)
        
        detector.fillColor = UIColor(red:0.95, green:0.61, blue:0.07, alpha:1.0)
        detector.position = CGPoint(x: (-self.frame.width / 4) + 25, y: -self.frame.height / 2 + 250)
        self.addChild(detector)
        
        
        
        // MARK: - Detector Label
        
        let detectorLabel = SKLabelNode(text: "Detector")
        
        detectorLabel.fontColor = .black
        detectorLabel.fontName = "AvenirNext-DemiBold"
        detectorLabel.fontSize = 25
        detectorLabel.position = CGPoint(x: detector.frame.midX, y: detector.position.y - 65)
        self.addChild(detectorLabel)
        
        
        
        // Define the atom DY
        
        let atomDY = detector.position.y - atomContainer.position.y
        
        // MARK: - Shoot atoms periodically
        
        timer = Timer.scheduledTimer(timeInterval: 0.25, target: self, selector: #selector(shootThings), userInfo: nil, repeats: true)
     
        
        
        // Create the atom
        
        atom = SKShapeNode(circleOfRadius: 10)
        
        atom.fillColor = UIColor(red:0.91, green:0.30, blue:0.24, alpha:1.0)
        atom.position = CGPoint(x: (-self.frame.width / 4) + 75, y: self.frame.height / 2 - 210)
        atom.zPosition = -1
        
        
        // Create the straight animation
        
        let moveAtomRight = SKAction.move(by: CGVector(dx: 0, dy: atomDY), duration: 2.0)
        let colorAtomDelay = SKAction.wait(forDuration: 0.45)
        let colorAtom = SKAction.customAction(withDuration: 0.0, actionBlock: { (node, elapsedTime) in
            (node as! SKShapeNode).fillColor = UIColor(red:0.16, green:0.50, blue:0.73, alpha:1.0)
        })
        
        let putAtomBack = SKAction.move(by: CGVector(dx: 0, dy: -atomDY), duration: 0)
        let uncolorAtom = SKAction.customAction(withDuration: 0.0, actionBlock: { (node, elapsedTime) in
            (node as! SKShapeNode).fillColor = UIColor(red:0.91, green:0.30, blue:0.24, alpha:1.0)
        })
        
        // Create grouped actions
        
        let moveAtom = SKAction.group([moveAtomRight, SKAction.sequence([colorAtomDelay, colorAtom])])
        let restoreAtom = SKAction.group([putAtomBack, uncolorAtom])
        
        atomAction = SKAction.sequence([moveAtom, restoreAtom])
        
        
        
        // Create the bend animation
        
        
        let atomMagnetDY = -100 - atomContainer.position.y
        let magnetDetectorDY = atomDY - atomMagnetDY
        
        
        // Bent curve
        
        let moveToMagnet = SKAction.move(by: CGVector(dx: 0, dy: atomMagnetDY), duration: 1.25)
        let bendAtom = SKAction.move(by: CGVector(dx: 160, dy: magnetDetectorDY), duration: 0.75)
        let moveAtomBack = SKAction.move(by: CGVector(dx: -160, dy: -atomDY), duration: 0)
        
        
        // Create grouped actions
        
        let moveAtomDown = SKAction.sequence([moveToMagnet, bendAtom])
        let moveAtomUp = SKAction.group([moveAtomBack])
        
        bendAction = SKAction.sequence([moveAtomDown, moveAtomUp])
        
        
        
        
        
        
        
        // MARK: - Radio Wave
        
        
        
        
        // MARK: - Create the Radio Container
        
        let radioEmitter = SKShapeNode(rect: CGRect(x: 0, y: 0, width: 130, height: 90), cornerRadius: 10)
        
        radioEmitter.strokeColor = .black
        radioEmitter.fillColor = .white
        radioEmitter.lineWidth = 5.0
        radioEmitter.position = CGPoint(x: (self.frame.width / 4) - 150, y:  210)
        
        self.addChild(radioEmitter)
        
        
        // MARK: - Radio Label
        
        let radioLabel = SKLabelNode(text: "Radio Wave Emitter")
        
        radioLabel.fontColor = .black
        radioLabel.fontName = "AvenirNext-DemiBold"
        radioLabel.fontSize = 25
        radioLabel.position = CGPoint(x: radioEmitter.frame.midX, y: radioEmitter.position.y + 135)
        
        self.addChild(radioLabel)
        
        
        
        // MARK: - Hertz Label
        
        let hertzLabel = SKLabelNode(text: "Hertz")
        
        hertzLabel.fontColor = .black
        hertzLabel.fontName = "AvenirNext-DemiBold"
        hertzLabel.fontSize = 23
        hertzLabel.position = CGPoint(x: radioEmitter.frame.midX, y: radioEmitter.position.y + 20)
        
        self.addChild(hertzLabel)
        
        
        // MARK: - Frequency Label
        
        frequencyLabel = SKLabelNode(text: "9.192.631.770")
        
        frequencyLabel.fontColor = .black
        frequencyLabel.fontName = "AvenirNext-DemiBold"
        frequencyLabel.fontSize = 16
        frequencyLabel.position = CGPoint(x: radioEmitter.frame.midX, y: radioEmitter.frame.maxY - 35)
        
        self.addChild(frequencyLabel)
        
        
        
        // Animate the label in and out
        
        let freqDelay = SKAction.wait(forDuration: 5.0)
        let fadeFreqOut1 = SKAction.fadeOut(withDuration: 0.5)
        let fadeFreqIn1 = SKAction.fadeIn(withDuration: 0.5)
        let freqDelay2 = SKAction.wait(forDuration: 5.5)
        
        let freqLabelAction = SKAction.sequence([freqDelay, fadeFreqOut1, fadeFreqIn1, freqDelay2, fadeFreqOut1, fadeFreqIn1])
        
        frequencyLabel.run(freqLabelAction)
        
        
        
        // Define wave DX
        
        let radioDX = detector.position.x - radioEmitter.position.y

        
        // Create the wave
        
        
        wave = SKShapeNode(rect: CGRect(x: 0, y: 0, width: 5, height: 60), cornerRadius: 2)
        
        wave.fillColor = .black
        wave.strokeColor = .black
        wave.position = CGPoint(x: (self.frame.width / 4) - 150, y: 225)
        wave.zPosition = -1
        
        
        // Create individual actions
        
        let moveWaveRight = SKAction.move(by: CGVector(dx: radioDX, dy: 0), duration: 3.5)
        let putWaveBack = SKAction.move(by: CGVector(dx: -radioDX, dy: 0), duration: 0)
        
        // Create grouped actions
        
        let moveWave = SKAction.group([moveWaveRight])
        let restoreWave = SKAction.group([putWaveBack])
        waveAction = SKAction.sequence([moveWave, restoreWave])
    
        
        
        
        
        // MARK: - Electromagnet
        
        
        // North Pole
        
        let northPole = SKShapeNode(rect: CGRect(x: 0, y: 0, width: 50, height: 60), cornerRadius: 6)
        
        northPole.fillColor = UIColor(red:0.50, green:0.55, blue:0.55, alpha:1.0)
        northPole.position = CGPoint(x: (-self.frame.width / 4) + 95, y:  -100)
        
        self.addChild(northPole)
        
        
        let northPoleLabel = SKLabelNode(text: "N")
        
        northPoleLabel.fontColor = .black
        northPoleLabel.fontName = "AvenirNext-DemiBold"
        northPoleLabel.fontSize = 27
        northPoleLabel.position = CGPoint(x: northPole.frame.midX - 3, y: northPole.frame.midY - 8)
        
        self.addChild(northPoleLabel)
        
        
        
        // South Pole
        
        let southPole = SKShapeNode(rect: CGRect(x: 0, y: 0, width: 50, height: 60), cornerRadius: 6)
        
        southPole.fillColor = UIColor(red:0.50, green:0.55, blue:0.55, alpha:1.0)
        southPole.position = CGPoint(x: (-self.frame.width / 4) + 5, y:  -100)
        
        self.addChild(southPole)
        
        
        let southPoleLabel = SKLabelNode(text: "S")
        
        southPoleLabel.fontColor = .black
        southPoleLabel.fontName = "AvenirNext-DemiBold"
        southPoleLabel.fontSize = 27
        southPoleLabel.position = CGPoint(x: southPole.frame.midX - 3, y: southPole.frame.midY - 8)
        
        self.addChild(southPoleLabel)
        
        
        
        
        
        
        // MARK: - The Quartz
        
        
        let quartzTexture = SKTexture(imageNamed: "Quartz.png")
        let quartz = SKSpriteNode(texture: quartzTexture)
        
        quartz.setScale(0.35)
        quartz.position = CGPoint(x: (self.frame.width / 4) - 250, y:  -175)
        
        
        self.addChild(quartz)
        
        
        
        let quartzLabel = SKLabelNode(text: "Quartz")
        
        quartzLabel.fontColor = .black
        quartzLabel.fontName = "AvenirNext-DemiBold"
        quartzLabel.fontSize = 24
        quartzLabel.position = CGPoint(x: quartz.frame.maxX + 110, y: southPole.frame.minY - 80)
        
        
        self.addChild(quartzLabel)
        
        
        
        
        
        
        // MARK: - Wiring between items
        
        
        let detectorWireTexture = SKTexture(imageNamed: "DetectorLine.png")
        let detectorWire = SKSpriteNode(texture: detectorWireTexture)
        
        detectorWire.setScale(0.75)
        detectorWire.position = CGPoint(x: -100, y: -self.frame.height / 2 + 355)
        detectorWire.zPosition = -1
        
        self.addChild(detectorWire)
        
        
        let transmitterWireTexture = SKTexture(imageNamed: "TransmitterLine.png")
        let transmitterWire = SKSpriteNode(texture: transmitterWireTexture)
        
        transmitterWire.setScale(0.75)
        transmitterWire.position = CGPoint(x: (self.frame.width / 4) - 155, y:  50)
        transmitterWire.zPosition = -1

        self.addChild(transmitterWire)
        
        
        
        
        // MARK: - Sync Label
        
        let syncLabel = SKLabelNode(text: "It's getting out of sync...")
        
        syncLabel.fontColor = .black
        syncLabel.fontName = "AvenirNext-DemiBold"
        syncLabel.fontSize = 27
        syncLabel.position = CGPoint(x: 75, y: (self.frame.height / 2) - 180)
        syncLabel.alpha = 0
        
        self.addChild(syncLabel)
        
        
        // Animate the label
        
        let delay = SKAction.wait(forDuration: 6.0)
        let fadeIn = SKAction.fadeIn(withDuration: 1.0)
        let delay2 = SKAction.wait(forDuration: 3.5)
        let fadeOut = SKAction.fadeOut(withDuration: 1.0)
        
        let syncLabelAction = SKAction.sequence([delay, fadeIn, delay2, fadeOut])
        
        
        syncLabel.run(syncLabelAction)
        
        
        
        // Modify the HerzLabel
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 5.0) {
            
            self.frequencyLabel.text = "7.121.421.196"
            
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 11.0) {
            
            self.frequencyLabel.text = "9.192.631.770"
            
        }
        
        
        
        
        // MARK: - Animate the shock
     
        
        // Play a sound
        
        let soundDelay = SKAction.wait(forDuration: 10.0)
        let soundAction = SKAction.playSoundFileNamed("shock.mp3", waitForCompletion: false)
        
        let combinedSound = SKAction.sequence([soundDelay, soundAction])
        
        run(combinedSound)
        
        
        
        // Animate the Quartz scale
        
        let quartzDelay = SKAction.wait(forDuration: 10.3)
        let enlargeQuartz = SKAction.scale(by: 1.15, duration: 0.2)
        let shrinkQuartz = SKAction.scale(by: (1.0 / 1.15), duration: 0.2)
        
        let combinedQuartz = SKAction.sequence([quartzDelay, enlargeQuartz, shrinkQuartz])

        quartz.run(combinedQuartz)
        
        
    }
    
    
    
    // MARK: - Shooting objects
    
    @objc func shootThings() {
        
        
        // MARK: - Spawning atoms
        
        
        if spawnedAtoms < 8 {
            
            spawnedAtoms += 1
            
            
            let localAtom = atom.copy() as! SKShapeNode
           
            self.addChild(localAtom)
            
            
            
            // Determine which action to run
            
            if bendingEnabled && bendNextAtom {
                
                // Bend current atom
                
                // Create a custom sequence
                
                let initialStraight = SKAction.repeat(atomAction, count: 2)
                let bend = SKAction.repeat(bendAction, count: 4)
                let foreverStraight = SKAction.repeatForever(atomAction)
                
                localAtom.run(SKAction.sequence([initialStraight, bend, foreverStraight]))

                bendNextAtom = false
                
            } else if bendingEnabled && !bendNextAtom {
                
                // Bend the next one
                
                localAtom.run(SKAction.repeatForever(atomAction))

                bendNextAtom = true
                
            } else {
                
                // Don't bend this one or the next one
                
                localAtom.run(SKAction.repeatForever(atomAction))

            }
        }
        
        
        
        // MARK: - Spawning radio waves
        
        
        if spawnedWaves < 15 {
            
            spawnedWaves += 1
            
            
            let localWave = wave.copy() as! SKShapeNode
            
            self.addChild(localWave)
            
            
            // Run infinitely
            
            localWave.run(SKAction.repeatForever(waveAction))

        }
        
        
        
        // MARK: - Determine the end of the loop
        
        if spawnedWaves >= 15 && spawnedAtoms >= 8 {
            
            timer.invalidate()
            
        }
    }
    
    
}
