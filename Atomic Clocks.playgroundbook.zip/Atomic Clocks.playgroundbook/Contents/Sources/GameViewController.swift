import UIKit
import SpriteKit


public class GameViewController: UIViewController {
    
    // MARK: - Variables
    
    public var skView: SKView?
    
    public var scene: Scene? = nil
    

    
    
    // MARK: - ViewDiDLoad
    
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        
        // Create the SKView
        
        self.skView = SKView(frame: self.view.frame)
        self.view.addSubview(self.skView!)
        

        if let skView = self.skView {
            
            scene = Scene(size: CGSize(width: self.view.frame.width, height: self.view.frame.width))
            scene?.anchorPoint = CGPoint(x: 0.5, y: 0.5)
            scene?.scaleMode = .aspectFill
            
            skView.presentScene(scene)
            
        }
    }
    
    
    
    // MARK: - Subviews
    
    override public func viewDidLayoutSubviews() {
        
        self.skView?.center = self.view.center
        self.skView?.frame = self.view.frame
        
    }
    
}

