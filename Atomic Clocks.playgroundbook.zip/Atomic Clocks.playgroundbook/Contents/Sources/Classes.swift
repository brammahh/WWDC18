
// MARK: - Helper structs

public struct Atom {
    
    public var state: State
    
    
    public init(state: State) {
        
        self.state = state
        
    }

}


// MARK: - Helper enums

public enum State {
    
    case lowEnergy
    case highEnergy
    
}

public enum CollectiveState {
    
    case allHighEnergy
    case someLowEnergy
}

public struct Endpoint {
    
    public var type: EndpointType
    
    public init(type: EndpointType) {
        
        self.type = type
        
    }
}

public enum EndpointType {
    
    case detector
    case elsewhere
}



// MARK: - Extensions

extension Sequence where Iterator.Element == Atom {
    
    public func determineState() -> CollectiveState {
        
        return .someLowEnergy
        
    }
    
}
