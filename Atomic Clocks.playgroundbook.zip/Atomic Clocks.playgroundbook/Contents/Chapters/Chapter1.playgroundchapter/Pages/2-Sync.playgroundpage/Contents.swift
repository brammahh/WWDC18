/*:
 # How do they work?
 
 Atomic clocks are self-correcting. When the Quartz (SiO₄) changes its frequency due to environmental factors like temperature, the radio transmitter connected to the Quartz will also send signals at a different frequency. Because of the change in frequency, less Cesium atoms will get into a higher energy state, so less atoms will reach the detector. When the detector doesn't detect enough atoms, it sends an electric pulse to the Quartz, altering its frequency again.
 
 
 ### Oh, no! It got out of sync!
 Something must be wrong in the code below.
 
 * callout(Route the atoms):
    Make sure the electromagnet routes the high energy and low energy atoms correctly. Higher energy state atoms should reach the detector, while lower energy state atoms should not.
 
 */
//#-hidden-code

import UIKit
import SpriteKit
import PlaygroundSupport


// Presenting the page

let gameVC = GameViewController()

PlaygroundPage.current.liveView = gameVC


var highEnergyCorrect = false
var lowEnergyCorrect = false


// MARK: - Endpoints

public var Detector = Endpoint(type: .detector)
public var Elsewhere =  Endpoint(type: .elsewhere)

//#-code-completion(everything, hide)
//#-code-completion(identifier, show, Detector, Elsewhere)

// MARK: - UI functions

public func route(_ atom: Atom, to: Endpoint) {
    
    switch atom.state {
        
    case .highEnergy:
        
        if to.type == .detector {
            
            highEnergyCorrect = true
            
        }
        
    case .lowEnergy:
        
        if to.type == .elsewhere {
            
            lowEnergyCorrect = true
            
        }
    }
    
}



//#-end-hidden-code
func routeAtom(atom: Atom) {
    switch atom.state {
        
    case .highEnergy:
        
        //#-editable-code Route it to the detector
        route(atom, to: <#T##Endpoint##Endpoint#>)
        //#-end-editable-code
        //#-hidden-code
        break
        //#-end-hidden-code
    
    case .lowEnergy:
        
        //#-editable-code Route it to the detector
        route(atom, to: <#T##Endpoint##Endpoint#>)
        //#-end-editable-code
        
        //#-hidden-code
        break
        //#-end-hidden-code
    }
}

//#-hidden-code

// Trigger the route once

routeAtom(atom: Atom(state: .highEnergy))
routeAtom(atom: Atom(state: .lowEnergy))


// Let the gameVC know about success


if highEnergyCorrect && lowEnergyCorrect {
    
    gameVC.scene!.bendingEnabled = true
    
    DispatchQueue.main.asyncAfter(deadline: .now() + 15.0) {
        
        PlaygroundPage.current.assessmentStatus = .pass(message: "You got it into sync! Let's look at the fruits of your work on the [next page](@next)!")

    }
    
} else {
    
    DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
        
        PlaygroundPage.current.assessmentStatus = .fail(hints: [], solution: "The `highEnergy` case should route to `Detector`. \n\nThe `lowEnergy` case should should route to `Elsewhere`")

    }
}




//#-end-hidden-code
